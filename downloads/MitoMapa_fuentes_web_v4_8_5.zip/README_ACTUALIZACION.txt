MITOMAPA CANARIO · WEB 4.8.5 · REA 4.8.4 · 22/10/2026

WEB PUBLICADA
https://mitomapa-canario.cgarcias.workers.dev/

EDITABLE VIGENTE
downloads/MitoMapa_canario_GobCan.elpx
Abrir con eXeLearning 4.0.5 o compatible y guardar una copia antes de adaptar.
Contiene 34 páginas, 118 iDevices, 42 juegos nativos y 16 MP3. Conserva los ocho
cuentos, las ocho escenas vigentes, las actividades editables, las guías y la
narración de Jesica. No contiene la aplicación web local ni la incrusta.
La última página incluye un enlace opcional a la web como recurso extra;
el Objeto de Aprendizaje nativo y la web son recursos diferenciados.

PAQUETES DE ESTA EDICIÓN
downloads/MitoMapa_REA_v4_8_5.zip: mismo editable ELPX 4.8.4 y documentación actual.
downloads/MitoMapa_fuentes_web_v4_8_5.zip: fuentes, imágenes, audios y herramientas
de la web, sin ELPX ni ZIP anidados. Las descargas históricas conservan sus
direcciones públicas, archivos y condiciones de publicación originales.

REVISIÓN WEB 4.8.5 · 22/10/2026
Nuevo juego opcional «Las piezas y sus islas», con arrastre, toque, clic y
teclado, referencia, pistas y reintentos. No modifica el pasaporte ni guarda
la práctica. Las siete vasijas y la caracola son recreaciones contemporáneas.
Las piezas del mapa principal se amplían ligeramente sin cambiar la geografía.
Wrangler y su bloqueo se actualizan a 4.152.0; se proponen actualizaciones
mensuales mediante Dependabot, sin fusión automática. El ELPX y la entrega
completa 4.8.4 conservan exactamente los mismos archivos.

REVISIÓN 4.8.4 · 22/10/2026
El pasaporte, los premios y las orientaciones actuales se refieren a piezas.
Se documenta la infografía de cerámica por isla entre los recursos consultados.
Las siete vasijas y la caracola, incluida la vasija de El Hierro con asas,
conservan sus imágenes, tamaños y posición. Las pintaderas siguen como decoración.
Las notas siguientes describen ediciones históricas.

REVISIÓN 4.8.1 · 20/10/2026
La portada combina cuatro pintaderas arriba, el mapa original completo y las
otras cuatro debajo, manteniendo las proporciones del mapa. Se corrige a
CC BY-SA 4.0 el pie del Pasaporte de pintaderas, también en sus datos internos.
La web se actualiza a 4.8.1 para mostrar la versión de la descarga y retirar
GobCan del botón y de su descripción. El ELPX 4.8.1 conserva sus bytes.

REVISIÓN EDITORIAL 4.8.0 · 20/10/2026
Portada más limpia, con autoría, licencia y pintaderas decorativas en dos filas,
sin referencia curricular. Justificación para el alumnado y navegación nativa
reorganizada sin perder los cuentos ni las actividades. Las fuentes se reúnen
por subapartados en cajas; las orientaciones docentes se despliegan en cajas.
Autoría y versión se concentran en sus apartados. Se escribe Objeto de
Aprendizaje sin abreviarlo y se revisan las formas de ustedes.
La web se ofrece únicamente mediante un enlace extra al final del ELPX;
no se incorpora como aplicación local ni se muestra incrustada. En ambos recursos se
incorporan agradecimientos y se mantiene CC BY-SA 4.0 para materiales propios,
con las condiciones específicas de terceros.

REVISIÓN VISUAL ANTERIOR 4.7.1 · 20/10/2026
Se retira la rosa de los vientos y se compactan el banco de fichas y las
cartelas del juego de nombres para facilitar el arrastre junto al mapa.
La selección de nombres, sus cautelas y la propuesta didáctica se conservan.

MEJORAS DE LA EDICIÓN ANTERIOR 4.7.0
Nuevo juego opcional Nombres de las islas, incluido en el Explorador portable:
asocia siete denominaciones y la ficha «Sin nombre documentado» con el mapa.
Permite arrastrar o seleccionar y colocar mediante toque, clic o teclado.
El aspecto de carta antigua es una recreación actual sobre la geografía del
mapa de MitoMapa; no es un mapa auténtico de los primeros conquistadores.
No concede pintaderas, no genera calificaciones ni condiciona la ruta.

FUENTES_CUENTOS.html#nombres-islas documenta la selección aportada por la autoría,
que informa de consultas con personas expertas en la época prehispánica de
Canarias. Se advierte de las incertidumbres de formas, grafías, cronología y
significado; la actividad no prueba fechas ni etimologías. Para La Graciosa,
«Sin nombre documentado» expresa que no se ha establecido aquí una denominación
indígena documentada, sin descartar visitas o usos ocasionales. Las fichas de
los ocho cuentos conservan su revisión del 14/10/2026 y no se modifica su texto.

Se conservan el reinicio coherente del progreso, la valoración voluntaria,
la ruta acordada y revisada por el profesorado, las herramientas de
sincronización y publicación y el protocolo imprimible para preparar un
pilotaje. Las guías incorporan el nuevo juego como ampliación opcional.

PROPUESTA MULTINIVEL
El profesorado selecciona las tareas, apoyos y anclaje curricular según su grupo.
Tres posibilidades: una sesión de unos 45 minutos para una isla; itinerario corto
de cuatro sesiones de unos 50 minutos para dos islas; banco completo opcional
de ocho a diez sesiones de 35–50 minutos. Los tiempos son orientativos.
GUIA_DOCENTE.html explica el desarrollo. GUIA_DOCENTE_GOBCAN.html contiene un
ejemplo curricular del tercer ciclo de Primaria, con 6.º como referencia y
adaptable a 5.º; no establece un nivel obligatorio para todo el recurso.
La ruta se cierra tras revisar las tareas pactadas. Las piezas reconocen
retos concretos y no sustituyen esa revisión ni son una calificación.

PILOTAJE PENDIENTE
No se ha aplicado todavía con alumnado y no se afirma eficacia educativa.
PROTOCOLO_PILOTAJE.html ofrece una hoja imprimible para recoger tiempos,
apoyos, dificultades, accesibilidad y mejoras sin identificadores del alumnado.

ADAPTACIÓN Y PUBLICACIÓN
El ELPX y la web independiente tienen seguimiento separado. Editar un iDevice
no modifica la web ni integra su progreso en el informe nativo. La web enlazada
desde la última página es un complemento opcional que requiere conexión.
tools/build_elpx.py corresponde al proyecto histórico 4.4.0 y no reconstruye
la adaptación GobCan vigente.
Para cambios solo en la web, conservar el ELPX y usar tools/update_release.py
para preparar manifiestos y paquetes. Para revisiones del proyecto nativo,
usar por separado tools/sync_current_elpx.py sin incorporar la aplicación web.
Comprobar ambas herramientas con --check y ejecutar tools/prepare_deploy.py.
El despliegue de main en GitHub publica el Worker. SHA256SUMS.txt determina los
archivos públicos y VERSION.json identifica las huellas de la descarga vigente.
Las descargas anteriores siguen siendo públicas. Abrir y exportar una copia del
ELPX con eXeLearning antes de distribuir una adaptación.

LICENCIA Y CONTACTO
CC BY-SA 4.0 para los materiales propios, también para usos comerciales, con
Reconocimiento y CompartirIgual. El mapa de TongApp conserva sus condiciones
originales de titularidad y libre uso educativo; no se relicencia como propio.
Las dependencias y fuentes externas mantienen sus condiciones específicas.
Conservar autoría, referencias y créditos.
Sugerencias y propuestas de mejora: sugerencias.mitomapacanario@gmail.com
