Web 3.9.1 / REA eXeLearning 4.0. Preparación: 30/09/2026.
Publicar el contenido completo de esta carpeta en el Worker existente.
No se ha efectuado el despliegue desde esta entrega. Consulta el LEEME_ACTUALIZACION.txt de la entrega completa.
Las fuentes web contienen también el REA 4.0; los enlaces antiguos se conservan en el paquete completo.
