MITOMAPA CANARIO · WEB 4.10.0
REA EDITABLE 4.8.9 · REVISIÓN 02/11/2026

WEB PUBLICADA
https://mitomapacanario.org/

EDITABLE VIGENTE
downloads/MitoMapa_canario_GobCan.elpx
Abrir con eXeLearning 4.0.5 y guardar una copia antes de adaptar.
El ELPX y la web son recursos diferenciados, con seguimientos independientes.

PAQUETES DE ESTA EDICIÓN
downloads/MitoMapa_REA_v4_10_0.zip: ELPX vigente y documentación de la entrega.
downloads/MitoMapa_fuentes_web_v4_10_0.zip: fuentes web sin ZIP ni ELPX anidados.
Los medios nuevos se recuperan con python3 tools/fetch_story_media.py.
Las huellas de los paquetes se consultan en SHA256SUMS.txt y en el catálogo externo.
La matriz EDICIONES.md distingue productos, idiomas y publicaciones observadas.
Las descargas históricas conservan sus archivos, direcciones y condiciones.

REVISIÓN ANTERIOR WEB 4.9.1 / ELPX 4.8.8 · 29/10/2026
Renderizado de metadatos nativos: texto inerte y formato HTML limitado saneado.
Se conservan medios, identidades, preguntas y seguimiento. Consultar las notas
de seguridad; no modifica la instalación de un editor eXe externo.

REVISIÓN ANTERIOR WEB 4.9.0 · 27/10/2026
Mapa/lista y mapa general, lectura contextual y preferencias, tarea de la sesión,
reanudación, pistas y fragmentos, fuentes con revisión docente y cierre creativo
para una o dos islas. ELPX 4.8.7, audios e imágenes conservan sus bytes.
El pilotaje y la sincronía de párrafos de las grabaciones siguen pendientes.

REVISIÓN TÉCNICA ANTERIOR WEB 4.8.13 · 25/10/2026
Se atienden cuatro hallazgos de seguridad en las herramientas y la publicación:
verificación pública HTTPS obligatoria, dependencias Python con hashes,
lectura acotada de ZIP/ELPX y validación de nuevas entradas WAV autocontenidas.
Se conserva exactamente el ELPX 4.8.7 y todos los audios, imágenes y descargas
anteriores. El protocolo y la entrega documental mantienen la base didáctica
web 4.8.12 / ELPX 4.8.7. Consultar CAMBIOS_WEB_4_8_13.md.

REVISIÓN ANTERIOR WEB 4.8.12 Y REA EDITABLE 4.8.7 · 25/10/2026
Se atiende la auditoría funcional y editorial: vocabulario, importación atómica,
enlaces docentes, cabecera accesible, créditos y dominio principal. Se emplea
aborigen/aborígenes en las explicaciones propias. Las escenas y los audios no cambian.
La edición nativa 4.8.6 se conserva en downloads/MitoMapa_canario_GobCan_v4_8_6.elpx.

REVISIÓN ANTERIOR WEB 4.8.11 Y REA EDITABLE 4.8.6 · 24/10/2026
Recursos presenta los materiales actuales de aula: cuaderno de ruta y pauta
cualitativa en HTML y CSV. Son opcionales, multinivel y adaptables a las tareas,
las modalidades y los apoyos acordados, sin puntuaciones ni calificaciones.
Se retira de la presentación actual el bloque de otras versiones, manteniendo
sus archivos publicados. Se revisan las guías y los textos de progreso y se
conservan los juegos, sus reglas y la miniatura social.
El ELPX 4.8.6 aclara que el pasaporte nativo se registra y revisa manualmente;
no se completa con premios automáticos ni se sincroniza con la web. Los cuentos,
las actividades, los audios y las imágenes conservan su contenido. La edición
nativa 4.8.5 se conserva en downloads/MitoMapa_canario_GobCan_v4_8_5.elpx.
El ejemplo curricular de tercer ciclo de Primaria es una posibilidad optativa;
el profesorado concreta la ruta y su anclaje curricular. Pilotaje pendiente.

REVISIÓN WEB 4.8.10 · 24/10/2026
Recursos muestra primero el acceso a la ficha de MitoMapa en la Mediateca,
con su logo y las opciones de uso o descarga que ofrece la ficha:
https://www3.gobiernodecanarias.org/medusa/mediateca/s/ecoescuela/item/271363
La ficha de la Mediateca identifica la edición 4.8.4. La descarga directa de
esta web corresponde al REA 4.8.5 e indica al navegador que guarde el archivo
como adjunto.
Si un navegador integrado no permite guardarlo, abre el enlace en un navegador
externo o descarga el paquete ZIP.
El REA 4.8.5 conserva exactamente sus bytes, su miniatura y su revisión nativa
del 23/10/2026. Las descargas anteriores mantienen sus archivos.

REVISIÓN NATIVA 4.8.5 Y PUBLICACIÓN WEB 4.8.9 · 23/10/2026
El ELPX incorpora una miniatura de su portada vigente para las vistas previas
de eXeLearning y los catálogos que utilizan la imagen del archivo. Se mantienen
los cuentos, las actividades, las narraciones y la organización del recurso.
La interfaz web, sus juegos y la miniatura social de la versión 4.8.8 conservan
su presentación. La web identifica y ofrece la descarga nativa actualizada.
La edición nativa anterior se conserva por separado en:
downloads/MitoMapa_canario_GobCan_v4_8_4.elpx

REVISIÓN WEB 4.8.8 · 23/10/2026
La miniatura social presenta un fondo azul degradado y una vasija decorativa.
Se retiran las figuras similares a ojos y se conserva el texto completo del
cartel, incluido «Ocho piezas». Su dirección versionada solicita renovar la
vista previa; los mensajes ya compartidos en WhatsApp pueden conservar la
imagen almacenada. El REA editable y la entrega completa 4.8.4 mantienen sus
mismos archivos.

REVISIÓN WEB 4.8.7 · 23/10/2026
La miniatura compartida muestra «Ocho piezas» y su dirección versionada solicita
renovar la vista previa. Los mensajes ya enviados por WhatsApp pueden conservar
la imagen almacenada; no se garantiza que se actualicen retrospectivamente.
El REA editable y la entrega completa 4.8.4 conservan sus mismos archivos.

REVISIÓN WEB 4.8.6 · 22/10/2026
Las tarjetas del banco de «Las piezas y sus islas» muestran solo las imágenes.
Se oculta el texto visible «Pieza N»; el nombre y el estado siguen disponibles
para lectores de pantalla. Se conservan las imágenes, el arrastre y las
alternativas con toque, clic y teclado. El ELPX y la entrega completa 4.8.4
permanecen intactos. Los paquetes anteriores conservan sus archivos.

REVISIÓN WEB 4.8.5 · 22/10/2026
Nuevo juego opcional «Las piezas y sus islas», con arrastre, toque, clic y
teclado, referencia, pistas y reintentos. No modifica el pasaporte ni guarda
la práctica. Las siete vasijas y la caracola son recreaciones contemporáneas.
Las piezas del mapa principal se amplían ligeramente sin cambiar la geografía.
Wrangler y su bloqueo se actualizan a 4.152.0; se proponen actualizaciones
mensuales mediante Dependabot, sin fusión automática. El ELPX y la entrega
completa 4.8.4 conservan exactamente los mismos archivos.

REVISIÓN 4.8.4 · 22/10/2026
El pasaporte, los premios y las orientaciones actuales se refieren a piezas.
Se documenta la infografía de cerámica por isla entre los recursos consultados.
Las siete vasijas y la caracola, incluida la vasija de El Hierro con asas,
conservan sus imágenes, tamaños y posición. Las pintaderas siguen como decoración.
Las notas siguientes describen ediciones históricas.

REVISIÓN 4.8.1 · 20/10/2026
La portada combina cuatro pintaderas arriba, el mapa original completo y las
otras cuatro debajo, manteniendo las proporciones del mapa. Se corrige a
CC BY-SA 4.0 el pie del Pasaporte de pintaderas, también en sus datos internos.
La web se actualiza a 4.8.1 para mostrar la versión de la descarga y retirar
GobCan del botón y de su descripción. El ELPX 4.8.1 conserva sus bytes.

REVISIÓN EDITORIAL 4.8.0 · 20/10/2026
Portada más limpia, con autoría, licencia y pintaderas decorativas en dos filas,
sin referencia curricular. Justificación para el alumnado y navegación nativa
reorganizada sin perder los cuentos ni las actividades. Las fuentes se reúnen
por subapartados en cajas; las orientaciones docentes se despliegan en cajas.
Autoría y versión se concentran en sus apartados. Se escribe Objeto de
Aprendizaje sin abreviarlo y se revisan las formas de ustedes.
La web se ofrece únicamente mediante un enlace extra al final del ELPX;
no se incorpora como aplicación local ni se muestra incrustada. En ambos recursos se
incorporan agradecimientos y se mantiene CC BY-SA 4.0 para materiales propios,
con las condiciones específicas de terceros.

REVISIÓN VISUAL ANTERIOR 4.7.1 · 20/10/2026
Se retira la rosa de los vientos y se compactan el banco de fichas y las
cartelas del juego de nombres para facilitar el arrastre junto al mapa.
La selección de nombres, sus cautelas y la propuesta didáctica se conservan.

MEJORAS DE LA EDICIÓN ANTERIOR 4.7.0
Nuevo juego opcional Nombres de las islas, incluido en el Explorador portable:
asocia siete denominaciones y la ficha «Sin nombre documentado» con el mapa.
Permite arrastrar o seleccionar y colocar mediante toque, clic o teclado.
El aspecto de carta antigua es una recreación actual sobre la geografía del
mapa de MitoMapa; no es un mapa auténtico de los primeros conquistadores.
No concede pintaderas, no genera calificaciones ni condiciona la ruta.

FUENTES_CUENTOS.html#nombres-islas documenta la selección aportada por la autoría,
que informa de consultas con personas expertas en la época prehispánica de
Canarias. Se advierte de las incertidumbres de formas, grafías, cronología y
significado; la actividad no prueba fechas ni etimologías. Para La Graciosa,
«Sin nombre documentado» expresa que no se ha establecido aquí una denominación
aborigen documentada, sin descartar visitas o usos ocasionales. Las fichas de
los ocho cuentos conservan su revisión del 14/10/2026 y no se modifica su texto.

Se conservan el reinicio coherente del progreso, la valoración voluntaria,
la ruta acordada y revisada por el profesorado, las herramientas de
sincronización y publicación y el protocolo imprimible para preparar un
pilotaje. Las guías incorporan el nuevo juego como ampliación opcional.

PROPUESTA MULTINIVEL
El profesorado selecciona las tareas, apoyos y anclaje curricular según su grupo.
Tres posibilidades: una sesión de unos 45 minutos para una isla; itinerario corto
de cuatro sesiones de unos 50 minutos para dos islas; banco completo opcional
de ocho a diez sesiones de 35–50 minutos. Los tiempos son orientativos.
GUIA_DOCENTE.html explica el desarrollo. GUIA_DOCENTE_GOBCAN.html contiene un
ejemplo curricular del tercer ciclo de Primaria, con 6.º como referencia y
adaptable a 5.º; no establece un nivel obligatorio para todo el recurso.
La ruta se cierra tras revisar las tareas pactadas. Las piezas reconocen
retos concretos y no sustituyen esa revisión ni son una calificación.

PILOTAJE PENDIENTE
No se ha aplicado todavía con alumnado y no se afirma eficacia educativa.
PROTOCOLO_PILOTAJE_WEB_4_9_0.html ofrece una hoja imprimible para recoger tiempos,
apoyos, dificultades, accesibilidad y mejoras sin identificadores del alumnado.

ADAPTACIÓN Y PUBLICACIÓN
El ELPX y la web independiente tienen seguimiento separado. Editar un iDevice
no modifica la web ni integra su progreso en el informe nativo. La web enlazada
desde la última página es un complemento opcional que requiere conexión.
tools/build_elpx.py corresponde al proyecto histórico 4.4.0 y no reconstruye
la adaptación GobCan vigente.
Para cambios solo en la web, conservar el ELPX y usar tools/update_release.py
para preparar manifiestos y paquetes. Para revisiones del proyecto nativo,
usar por separado tools/sync_current_elpx.py sin incorporar la aplicación web.
Comprobar ambas herramientas con --check y ejecutar tools/prepare_deploy.py.
El despliegue de main en GitHub publica el Worker. SHA256SUMS.txt determina los
archivos públicos y VERSION.json identifica las huellas de la descarga vigente.
Las descargas anteriores siguen siendo públicas. Abrir y exportar una copia del
ELPX con eXeLearning antes de distribuir una adaptación.

LICENCIA Y CONTACTO
CC BY-SA 4.0 para los materiales propios, también para usos comerciales, con
Reconocimiento y CompartirIgual. El mapa de TongApp conserva sus condiciones
originales de titularidad y libre uso educativo; no se relicencia como propio.
Las dependencias y fuentes externas mantienen sus condiciones específicas.
Conservar autoría, referencias y créditos.
Sugerencias y propuestas de mejora: sugerencias.mitomapacanario@gmail.com
